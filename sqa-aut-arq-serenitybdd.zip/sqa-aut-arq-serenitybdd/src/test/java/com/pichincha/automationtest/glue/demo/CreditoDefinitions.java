package com.pichincha.automationtest.glue.demo;

import com.pichincha.automationtest.ui.EjerciciosNTTDATA.RegistroDemoBlaze;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Open;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;

import static net.serenitybdd.screenplay.GivenWhenThen.when;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;

public class DemoblazeGlue {
    @Managed
    WebDriver driver;

    private WebDriver navegador;

    //private Actor actor =Actor.named("Global");
    private PageCalculadora PageCalculadora = new PageCalculadora();
    @Given("que {actor} navega por la calculadora")
    public void queJuanNavegaPorLaCalculadora(Actor actor) {

        actor.wasAbleTo(Task.where("Credito",Open.browserOn().the(PageCalculadora)));
    }
    @When("selecciona el producto que le interesa Credito interes social, con un costo de {string}, siendo {string} el valor a solicitar, pagandolo a un plazo de {string} años y con una amortizacion {string}")
    public void seleccionaElProductoQueLeInteresaCreditoInteresSocialConUnCostoDeSiendoElValorASolicitarPagandoloAUnPlazoDeAñosYConUnaAmortizacion(String arg0, String arg1, String arg2, String arg3) {
        Actor actor = theActorInTheSpotlight();
        when(actor).wasAbleTo(Calculadora.interesSocial(arg0, arg1,  arg2,  arg3));
    }

    @Then("visualizara los resultados del calculo, siendo la cuota mensual aproximada de {string}, con una Tasa de interes del {string},")
    public void visualizaraLosResultadosDelCalculoSiendoLaCuotaMensualAproximadaDeConUnaTasaDeInteresDel(String arg0, String arg1) {

    }
}