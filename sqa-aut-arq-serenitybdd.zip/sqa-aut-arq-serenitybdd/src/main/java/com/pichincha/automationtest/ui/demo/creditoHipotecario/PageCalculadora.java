package com.pichincha.automationtest.ui.demo.creditoHipotecario;

import net.serenitybdd.core.pages.PageObject;

import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.webdriver.shadow.ByShadow;
import org.openqa.selenium.By;
@DefaultUrl("https://creditohipotecario.pichincha.com/calculadora")
public class PageCalculadora extends PageObject {
    public static final Target VIVIENDA_CHECK = Target.the("'CHECK VIVIENDA'").located(By.xpath("//*[@id=\"setVipVisProductCheckboxInput\"]"));
    public static final Target VALOR_FIELD= Target.the("'VALOR VIVIENDA'").located(By.xpath("//*[@id=\"home-price-calculator\"]"));
    public static final Target VALPRESTAMO_FIELD = Target.the("'CHECK VIVIENDA'").located(By.xpath("//*[@id=\"requested-amount-calculator\"]"));
    public static final Target TIEMPO_FIELD = Target.the("'CHECK VIVIENDA'").located(By.xpath("//*[@id=\"loan-term-years-calculator\"]"));
    public static final Target ALEMANA_CHECK = Target.the("'CHECK VIVIENDA'").located(By.xpath("//*[@id=\"setGermanAmortizationCheckboxInput\"]"));

    public static final Target CALCULAR_BOTON1 = Target.the("'CHECK VIVIENDA'").
            located(By.xpath("//*[@id=\"inputsSection\"]/div[4]/pichincha-grid/div/pichincha-grid[1]/div/div"));



    private static final String HOST_BOTON = "#calculateButton";


    private static final String BOTON_TARGET = "button";
    public static final Target CALCULAR_BOTON = Target.the("'bOTON cALCULAR'").
            located(ByShadow.cssSelector(BOTON_TARGET, HOST_BOTON));
}
