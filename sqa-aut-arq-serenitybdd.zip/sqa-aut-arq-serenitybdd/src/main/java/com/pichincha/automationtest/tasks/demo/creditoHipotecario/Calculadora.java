package com.pichincha.automationtest.tasks.demo.creditoHipotecario;

import com.pichincha.automationtest.ui.demo.creditoHipotecario.PageCalculadora;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.waits.WaitUntil;

import static net.serenitybdd.screenplay.Tasks.instrumented;
import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isVisible;

public class Calculadora implements Task {
    String valorVivienda;
    String valorPrestamo;
    String plazo;
    String tipoAmortizacion;
    public Calculadora(String valorVivienda, String valorPrestamo, String plazo, String tipoAmortizacion) {
        this.valorVivienda=valorVivienda;
        this.valorPrestamo=valorPrestamo;
        this.plazo=plazo;
        this.tipoAmortizacion=tipoAmortizacion;

    }

    public static Performable interesSocial(String valorVivienda, String valorPrestamo, String plazo, String tipoAmortizacion){
        return instrumented(Calculadora.class, valorVivienda,  valorPrestamo,  plazo,  tipoAmortizacion);
    }
    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                WaitUntil.the(PageCalculadora.VIVIENDA_CHECK, isVisible()).forNoMoreThan(20).seconds(),
                Click.on(PageCalculadora.VIVIENDA_CHECK),
                Enter.keyValues(valorVivienda).into(PageCalculadora.VALOR_FIELD),
                Enter.keyValues(valorPrestamo).into(PageCalculadora.VALPRESTAMO_FIELD),
                Enter.keyValues(plazo).into(PageCalculadora.TIEMPO_FIELD),
                Click.on(PageCalculadora.ALEMANA_CHECK),
                WaitUntil.the(PageCalculadora.CALCULAR_BOTON1, isVisible()).forNoMoreThan(20).seconds(),
                Click.on(PageCalculadora.CALCULAR_BOTON1)
        );

    }
}
